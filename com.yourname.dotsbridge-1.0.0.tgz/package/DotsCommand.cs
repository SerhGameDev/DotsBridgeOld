﻿using System;
using Unity.Entities;
using UnityEngine;

namespace DotsBridge
{
    /// <summary>
    /// Контейнер для отложенного выполнения цепочки команд над DOTS-сущностями.
    /// </summary>
    public class DotsCommand
    {
        public readonly string Name;

        private Func<EntityBatch> _targetResolver;
        private bool _requiresDispose;
        private Action<EntityBatch> _actions;

        public DotsCommand(string name)
        {
            Name = name;
        }

        /// <summary>
        /// Позволяет передать любую внешнюю функцию для выполнения над батчем.
        /// Это делает команду бесконечно расширяемой через Extension методы.
        /// </summary>
        public DotsCommand Do(Action<EntityBatch> customAction)
        {
            _actions += customAction;
            return this;
        }

        // --- УКАЗАНИЕ ЦЕЛИ (TARGET RESOLVERS) ---

        public DotsCommand GetById(string targetId)
        {
            _targetResolver = () => Dots.GetById(targetId);
            _requiresDispose = false;
            return this;
        }

        public DotsCommand GetByTags(params string[] tags)
        {
            _targetResolver = () => Dots.GetByTags(tags);
            _requiresDispose = true;
            return this;
        }

        /// <summary>
        /// Позволяет внедрить кастомную логику получения (или создания) сущностей.
        /// Используется, например, в SpawnerBuilder.
        /// </summary>
        public DotsCommand SetTargetResolver(Func<EntityBatch> resolver, bool requiresDispose)
        {
            _targetResolver = resolver;
            _requiresDispose = requiresDispose;
            return this;
        }

        // --- НАКОПЛЕНИЕ ДЕЙСТВИЙ (ACTIONS) ---

        public DotsCommand AddComponent<T>() where T : unmanaged, IComponentData
        {
            _actions += batch => batch.AddComponent<T>();
            return this;
        }

        public DotsCommand SetData<T>(T data) where T : unmanaged, IComponentData
        {
            _actions += batch => batch.SetData(data);
            return this;
        }

        public DotsCommand LogCount(string prefix = "Command executed on entities:")
        {
            _actions += batch => Debug.Log($"[{Name}] {prefix} {batch.Entities.Length}");
            return this;
        }

        // --- ВЫПОЛНЕНИЕ ---

        /// <summary>
        /// Разрешает цель и выполняет все накопленные действия.
        /// </summary>
        public void Execute()
        {
            if (_targetResolver == null)
            {
                Debug.LogError($"Команда '{Name}' не имеет цели! Вызовите GetById, GetByTags или используйте Spawn перед Execute.");
                return;
            }

            // 1. Получаем свежий батч (в реальном времени)
            EntityBatch batch = _targetResolver.Invoke();

            // 2. Выполняем все действия, если они есть
            _actions?.Invoke(batch);

            // 3. Безопасно очищаем память, если это был динамический запрос
            if (_requiresDispose)
            {
                batch.Dispose();
            }
        }
    }
}