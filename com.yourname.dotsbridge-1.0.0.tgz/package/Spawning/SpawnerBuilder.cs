﻿using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;

namespace DotsBridge
{
    public struct SpawnerBuilder
    {
        private EntityManager _manager;
        private Entity _prefab;
        private int _count;
        private float3 _position;
        private quaternion _rotation;
        private float _scale;

        public SpawnerBuilder(Entity prefab)
        {
            _manager = Dots.Manager;
            _prefab = prefab;
            _count = 1;
            _position = float3.zero;
            _rotation = quaternion.identity;
            _scale = 1f;
        }

        public SpawnerBuilder SetCount(int count) { _count = count; return this; }
        public SpawnerBuilder SetPosition(Vector3 position) { _position = position; return this; }
        public SpawnerBuilder SetRotation(Quaternion rotation) { _rotation = rotation; return this; }
        public SpawnerBuilder SetScale(float scale) { _scale = scale; return this; }

        /// <summary>
        /// Формирует DotsCommand, где TargetResolver — это логика инстанцирования.
        /// </summary>
        public DotsCommand Spawn(string commandName = "SpawnCommand")
        {
            var command = new DotsCommand(commandName);

            // Кэшируем данные для замыкания (closure), чтобы резолвер помнил параметры
            var manager = _manager;
            var prefab = _prefab;
            var count = _count;
            var pos = _position;
            var rot = _rotation;
            var scale = _scale;

            // Назначаем резолвером логику спауна
            command.SetTargetResolver(() =>
            {
                if (prefab == Entity.Null)
                {
                    UnityEngine.Debug.LogError("[DotsBridge] Попытка заспавнить Entity.Null!");
                    return new EntityBatch(default, manager);
                }

                NativeList<Entity> spawnedEntities = new NativeList<Entity>(count, Allocator.TempJob);

                using (var tempArray = new NativeArray<Entity>(count, Allocator.Temp))
                {
                    manager.Instantiate(prefab, tempArray);
                    spawnedEntities.AddRange(tempArray);
                }

                var transform = LocalTransform.FromPositionRotationScale(pos, rot, scale);
                foreach (var entity in spawnedEntities)
                {
                    manager.SetComponentData(entity, transform);
                }

                // Возвращаем свежеиспеченный батч, который пойдет дальше по цепочке
                return new EntityBatch(spawnedEntities, manager);

            }, true); // true означает, что после Execute() вызовется batch.Dispose()

            return command;
        }
    }
    public static partial class Dots
    {
        /// <summary>
        /// Точка входа для спауна. Возвращает легковесный билдер.
        /// </summary>
        public static SpawnerBuilder Spawn(Entity prefab)
        {
            return new SpawnerBuilder(prefab);
        }
        public static SpawnerBuilder BeginSpawn(Entity prefab)
        {
            return new SpawnerBuilder(prefab);
        }
        public static SpawnerBuilder BeginSpawn(string namePrefab)
        {
            return new SpawnerBuilder(GetPrefab(namePrefab));
        }
    }
}