﻿using DotsBridge.Movement;
using DotsBridge.Spawning;
using System;
using System.Runtime.CompilerServices;
using Unity.Collections;
using Unity.Entities;

namespace DotsBridge
{
    public readonly partial struct EntityBatch : IDisposable
    {
        public readonly NativeList<Entity> Entities;
        public readonly EntityManager Manager;

        public EntityBatch(NativeList<Entity> entities, EntityManager manager)
        {
            Entities = entities;
            Manager = manager;
        }

        public void Dispose()
        {
            if (Entities.IsCreated)
                Entities.Dispose();
        }
    }
    public static partial class Dots
    {
        public static DotsCommand Command(string id)
        {
            return new DotsCommand(id);
        }

    }
}