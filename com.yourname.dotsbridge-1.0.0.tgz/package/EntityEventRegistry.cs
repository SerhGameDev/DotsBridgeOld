﻿using System;
using System.Collections.Generic;
using Unity.Entities;

namespace DotsBridge
{
    // 1. Метка: Сущность должна быть уничтожена в конце кадра
    public struct DestroyTag : IComponentData { }

    // 2. DOTS-данные: Какой префаб заспавнить при смерти (партиклы/лут)
    public struct SpawnOnDeath : IComponentData
    {
        public Entity Prefab;
    }

    // 3. Реестр OOP-событий (Мост для делегатов)
    public static class EntityEventRegistry
    {
        // Словарь: Entity -> Действие при ее уничтожении
        public static readonly Dictionary<Entity, Action<Entity>> OnDestroyEvents = new Dictionary<Entity, Action<Entity>>();

        public static void RegisterDestroy(Entity entity, Action<Entity> action)
        {
            if (OnDestroyEvents.ContainsKey(entity))
                OnDestroyEvents[entity] += action;
            else
                OnDestroyEvents[entity] = action;
        }
    }
}