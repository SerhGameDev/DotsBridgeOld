﻿using Unity.Entities;
namespace DotsBridge.Systems
{
    public struct DestroyTimer : IComponentData
    {
        public float Value;
    }
}