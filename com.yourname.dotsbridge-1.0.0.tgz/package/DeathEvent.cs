﻿using Unity.Entities;

namespace DotsBridge
{
    public struct DeathEvent : IComponentData, IEnableableComponent
    {
    }
}