﻿namespace DotsBridge
{
    public static class DeathEventExtensions
    {
        /// <summary>
        /// Добавляет компонент DeathEvent к сущностям и сразу его ВЫКЛЮЧАЕТ.
        /// Идеально вызывать сразу после Spawn().
        /// </summary>
        public static EntityBatch AddDeathEvent(this EntityBatch batch)
        {
            batch.Manager.AddComponent<DeathEvent>(batch.Entities.AsArray());

            // Сразу переводим в спящий режим
            foreach (var entity in batch.Entities)
            {
                batch.Manager.SetComponentEnabled<DeathEvent>(entity, false);
            }
            return batch;
        }

        /// <summary>
        /// Триггер смерти: ВКЛЮЧАЕТ DeathEvent. 
        /// Сущность будет жить до конца текущего кадра, позволяя другим системам отреагировать.
        /// </summary>
        public static EntityBatch TriggerDeath(this EntityBatch batch)
        {
            foreach (var entity in batch.Entities)
            {
                batch.Manager.SetComponentEnabled<DeathEvent>(entity, true);
            }
            return batch;
        }

        // Поддержка цепочек DotsCommand
        public static DotsCommand AddDeathEvent(this DotsCommand cmd) => cmd.Do(b => b.AddDeathEvent());
        public static DotsCommand TriggerDeath(this DotsCommand cmd) => cmd.Do(b => b.TriggerDeath());
    }
}