﻿using Unity.Entities;

namespace DotsBridge
{
    public struct TeamBlueTag : IComponentData { }
}