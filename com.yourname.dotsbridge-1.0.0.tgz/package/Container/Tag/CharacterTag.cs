﻿using Unity.Entities;

namespace DotsBridge
{
    public struct CharacterTag : IComponentData { }
}