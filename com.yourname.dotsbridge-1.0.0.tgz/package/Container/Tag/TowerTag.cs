﻿using Unity.Entities;

namespace DotsBridge
{
    public struct TowerTag : IComponentData { }
}