﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Unity.Collections;
using Unity.Entities;

namespace DotsBridge
{
    public static partial class Dots
    {
        // =========================================================
        // ВНУТРЕННИЕ ДАННЫЕ
        // =========================================================
        #region Internal Data

        public static readonly Dictionary<int, EntityContainer> Containers = new Dictionary<int, EntityContainer>();
        private static readonly Dictionary<string, ComponentType> TagRegistry = new Dictionary<string, ComponentType>();

        #endregion

        // =========================================================
        // СИСТЕМА ID (КЭШИРУЕМАЯ)
        // =========================================================
        #region ID System

        /// <summary>
        /// Получает или создает кэшированный контейнер сущностей по строковому ID.
        /// ВНИМАНИЕ: Метод скрыт, чтобы защитить словарь от внешних модификаций.
        /// Скорость: Высокая ($O(1)$ по словарю), но при первом вызове выполняет тяжелый поиск.
        /// Лимит: Идеально для уникальных/редких объектов на сцене (Игрок, Менеджер).
        /// </summary>
        private static EntityContainer GetOrCreateContainer(string idString)
        {
            var id = GetHash(idString);

            if (!Containers.TryGetValue(id, out var container))
            {
                container = new EntityContainer(id, Manager);

                // Первичное заполнение
                var tempBatch = Find(idString, Allocator.Temp);
                container.Entities.AddRange(tempBatch.Entities.AsArray());
                tempBatch.Dispose();

                Containers.Add(id, container);
            }
            return container;
        }

        /// <summary>
        /// Получает батч сущностей по уникальному строковому ID.
        /// ВНИМАНИЕ: Не вызывайте Dispose() у полученного батча! Сущностями управляет глобальный контейнер.
        /// Скорость: Очень высокая (мгновенный доступ к кэшу).
        /// Лимит: Безопасно вызывать каждый кадр (в методах Update).
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch GetById(string id)
        {
            return GetOrCreateContainer(id).GetBatch();
        }

        #endregion

        // =========================================================
        // СИСТЕМА ТЕГОВ (СТРОКИ)
        // =========================================================
        #region Tag System

        /// <summary>
        /// Регистрирует строковый тег и привязывает его к пустому компоненту (IComponentData).
        /// ВНИМАНИЕ: Без регистрации строковый поиск по тегу будет возвращать пустой список!
        /// Скорость: Мгновенно.
        /// Лимит: Вызывать только один раз при старте игры/сцены (Bootstrapper).
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void RegisterTag<T>(string tagName) where T : struct, IComponentData
        {
            TagRegistry[tagName] = ComponentType.ReadOnly<T>();
        }

        /// <summary>
        /// Получает сущности, содержащие ВСЕ указанные строковые теги.
        /// ВНИМАНИЕ: Обязательно вызовите Dispose() у батча для избежания утечек памяти!
        /// Скорость: Средняя (Поиск в словаре + аллокация NativeList).
        /// Лимит: Удобно для разовых событий и скриптинга. Избегать частого вызова в Update.
        /// </summary>
        public static EntityBatch GetByTags(params string[] tags)
        {
            if (tags == null || tags.Length == 0)
                throw new ArgumentException("Укажите хотя бы один тег для поиска.");

            var types = new ComponentType[tags.Length];
            for (int i = 0; i < tags.Length; i++)
            {
                if (TagRegistry.TryGetValue(tags[i], out var type))
                {
                    types[i] = type;
                }
                else
                {
                    UnityEngine.Debug.LogWarning($"Тег '{tags[i]}' не зарегистрирован в DotsBridge.");
                    return new EntityBatch(new NativeList<Entity>(Allocator.Persistent), Manager);
                }
            }

            return Get(types);
        }

        #endregion

        // =========================================================
        // СИСТЕМА КОМПОНЕНТОВ (БАЗОВЫЙ ПОИСК И ДЖЕНЕРИКИ ДО 6)
        // =========================================================
        #region Component Query System

        /// <summary>
        /// Базовый метод. Получает сущности, содержащие ВСЕ указанные типы компонентов.
        /// ВНИМАНИЕ: Обязательно вызовите Dispose() у батча для избежания утечек памяти!
        /// Скорость: Средняя (Создает EntityQuery и аллоцирует NativeList).
        /// Лимит: Из-за аллокации памяти лучше не использовать каждый кадр.
        /// </summary>
        public static EntityBatch Get(params ComponentType[] componentTypes)
        {
            if (componentTypes == null || componentTypes.Length == 0)
                throw new ArgumentException("Укажите хотя бы один компонент для поиска.");

            var queryDesc = new EntityQueryDesc { All = componentTypes };
            var query = Manager.CreateEntityQuery(queryDesc);
            var entityArray = query.ToEntityArray(Allocator.Temp);

            var entityList = new NativeList<Entity>(entityArray.Length, Allocator.Persistent);
            entityList.AddRange(entityArray);

            entityArray.Dispose();
            query.Dispose();

            return new EntityBatch(entityList, Manager);
        }

        public static DotsCommand Get(this DotsCommand сommand, params ComponentType[] componentTypes) => 
            сommand.Do(batch => Get(componentTypes));

        /// <summary>
        /// Получает сущности по 1 компоненту-маркеру.
        /// ВНИМАНИЕ: Обязательно вызовите Dispose() у батча для избежания утечек памяти!
        /// Скорость: Средняя (Аллокация NativeList).
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch Get<T1>()
            where T1 : struct, IComponentData
            => Get(ComponentType.ReadOnly<T1>());

        public static DotsCommand Get<T1>(this DotsCommand сommand)
            where T1 : struct, IComponentData => сommand.Do(batch => Get<T1>());

        /// <summary>
        /// Получает сущности по 2 компонентам-маркерам.
        /// ВНИМАНИЕ: Обязательно вызовите Dispose() у батча для избежания утечек памяти!
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch Get<T1, T2>()
            where T1 : struct, IComponentData
            where T2 : struct, IComponentData
            => Get(ComponentType.ReadOnly<T1>(), ComponentType.ReadOnly<T2>());

        /// <summary>
        /// Получает сущности по 3 компонентам-маркерам.
        /// ВНИМАНИЕ: Обязательно вызовите Dispose() у батча для избежания утечек памяти!
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch Get<T1, T2, T3>()
            where T1 : struct, IComponentData
            where T2 : struct, IComponentData
            where T3 : struct, IComponentData
            => Get(ComponentType.ReadOnly<T1>(), ComponentType.ReadOnly<T2>(), ComponentType.ReadOnly<T3>());

        /// <summary>
        /// Получает сущности по 4 компонентам-маркерам.
        /// ВНИМАНИЕ: Обязательно вызовите Dispose() у батча для избежания утечек памяти!
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch Get<T1, T2, T3, T4>()
            where T1 : struct, IComponentData
            where T2 : struct, IComponentData
            where T3 : struct, IComponentData
            where T4 : struct, IComponentData
            => Get(ComponentType.ReadOnly<T1>(), ComponentType.ReadOnly<T2>(), ComponentType.ReadOnly<T3>(), ComponentType.ReadOnly<T4>());

        /// <summary>
        /// Получает сущности по 5 компонентам-маркерам.
        /// ВНИМАНИЕ: Обязательно вызовите Dispose() у батча для избежания утечек памяти!
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch Get<T1, T2, T3, T4, T5>()
            where T1 : struct, IComponentData
            where T2 : struct, IComponentData
            where T3 : struct, IComponentData
            where T4 : struct, IComponentData
            where T5 : struct, IComponentData
            => Get(ComponentType.ReadOnly<T1>(), ComponentType.ReadOnly<T2>(), ComponentType.ReadOnly<T3>(), ComponentType.ReadOnly<T4>(), ComponentType.ReadOnly<T5>());

        /// <summary>
        /// Получает сущности по 6 компонентам-маркерам.
        /// ВНИМАНИЕ: Обязательно вызовите Dispose() у батча для избежания утечек памяти!
        /// Скорость: Средняя (Аллокация NativeList).
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch Get<T1, T2, T3, T4, T5, T6>()
            where T1 : struct, IComponentData
            where T2 : struct, IComponentData
            where T3 : struct, IComponentData
            where T4 : struct, IComponentData
            where T5 : struct, IComponentData
            where T6 : struct, IComponentData
            => Get(ComponentType.ReadOnly<T1>(), ComponentType.ReadOnly<T2>(), ComponentType.ReadOnly<T3>(), ComponentType.ReadOnly<T4>(), ComponentType.ReadOnly<T5>(), ComponentType.ReadOnly<T6>());

        #endregion
        // =========================================================
        // СИСТЕМА ПРЕФАБОВ (КОНТЕЙНЕР)
        // =========================================================
        #region Prefab System

        private static DynamicBuffer<PrefabRegistryElement> _prefabBuffer;
        private static bool _isPrefabBufferCached = false;

        /// <summary>
        /// Возвращает Entity-префаб из глобального контейнера по его строковому имени.
        /// </summary>
        public static Entity GetPrefab(string name)
        {
            // 1. Кэшируем буфер при первом вызове
            if (!_isPrefabBufferCached)
            {
                var query = Manager.CreateEntityQuery(typeof(PrefabRegistryElement));

                if (query.IsEmpty)
                {
                    UnityEngine.Debug.LogError("[DotsBridge] PrefabContainer не найден на сцене! Убедитесь, что объект с PrefabContainerAuthoring находится в SubScene.");
                    return Entity.Null;
                }

                _prefabBuffer = query.GetSingletonBuffer<PrefabRegistryElement>(true);
                _isPrefabBufferCached = true;
            }

            // 2. Ищем префаб по хэшу
            int hash = GetHash(name);
            foreach (var element in _prefabBuffer)
            {
                if (element.NameHash == hash)
                {
                    return element.PrefabEntity;
                }
            }

            UnityEngine.Debug.LogError($"[DotsBridge] Префаб с именем '{name}' не найден в контейнере!");
            return Entity.Null;
        }

        /// <summary>
        /// Сбрасывает кэш префабов (вызывать при смене сцены или перезапуске).
        /// </summary>
        public static void ClearPrefabCache()
        {
            _isPrefabBufferCached = false;
        }

        #endregion
    }
    /// <summary>
     /// Элемент буфера, хранящий хэш имени и ссылку на запеченный Entity префаб.
     /// </summary>
    [InternalBufferCapacity(32)] // Предварительно выделяем память под 32 префаба
    public struct PrefabRegistryElement : IBufferElementData
    {
        public int NameHash;
        public Entity PrefabEntity;
    }
}