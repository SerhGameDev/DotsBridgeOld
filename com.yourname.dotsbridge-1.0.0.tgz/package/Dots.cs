﻿using Unity.Collections;
using Unity.Entities;

namespace DotsBridge
{
    public static partial class Dots
    {
        public static World World => World.DefaultGameObjectInjectionWorld;
        public static EntityManager Manager => World.EntityManager;

        public static int GetHash(string id) => new FixedString32Bytes(id).GetHashCode();
    }
}
