﻿using Unity.Entities;
using UnityEngine;

namespace Assets.DotsBridge.Move.TransformSync
{
    public class LinkedTransform : IComponentData
    {
        public Transform Transform;
    }
}
