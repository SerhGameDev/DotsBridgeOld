﻿using Unity.Entities;

namespace Assets.DotsBridge.Move.TransformSync
{
    public struct SyncSettings : IComponentData
    {
        public enum Mode
        {
            CopyFromGameObject, 
            CopyToGameObject 
        }

        public Mode SyncMode;
        public bool SyncPosition;
        public bool SyncRotation;
    }
}
