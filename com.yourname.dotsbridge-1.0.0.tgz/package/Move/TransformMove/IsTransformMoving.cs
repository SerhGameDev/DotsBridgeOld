using Unity.Entities;

namespace DotsBridge.Movement
{
    public struct IsTransformMoving : IComponentData, IEnableableComponent { }

}