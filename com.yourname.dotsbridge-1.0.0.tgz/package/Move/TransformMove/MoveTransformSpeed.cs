using Unity.Entities;

namespace DotsBridge.Move
{
    public struct MoveTransformSpeed : IComponentData
    {
        public float Value;
    }

}