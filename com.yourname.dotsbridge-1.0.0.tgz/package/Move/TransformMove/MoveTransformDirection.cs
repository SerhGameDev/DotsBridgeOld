using Unity.Entities;
using Unity.Mathematics;

namespace DotsBridge.Move
{
    public struct MoveTransformDirection : IComponentData
    {
        public float3 Value;
    }

}