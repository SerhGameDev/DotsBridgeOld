﻿using System;
using System.Collections.Generic;
using Unity.Entities;

namespace DotsBridge
{
    public static class DestroyExtensions
    {
        /// <summary>
        /// Помечает сущности на удаление (будут уничтожены в конце кадра системным сборщиком).
        /// </summary>
        public static EntityBatch Destroy(this EntityBatch batch)
        {
            if (batch.Entities.IsCreated && batch.Entities.Length > 0)
            {
                // Быстро вешаем тег смерти на весь батч
                batch.Manager.AddComponent<DestroyTag>(batch.Entities.AsArray());
            }
            return batch;
        }

        // --- НОВЫЕ ЭКСТЕНШЕНЫ ДЛЯ ПОДПИСОК ---

        /// <summary>
        /// [DOTS] Указывает, какой Entity-префаб заспавнить на месте этой сущности при ее смерти (партиклы/взрыв).
        /// </summary>
        public static EntityBatch SetSpawnOnDeath(this EntityBatch batch, Entity prefabToSpawn)
        {
            batch.Manager.AddComponent<SpawnOnDeath>(batch.Entities.AsArray());
            foreach (var entity in batch.Entities)
            {
                batch.Manager.SetComponentData(entity, new SpawnOnDeath { Prefab = prefabToSpawn });
            }
            return batch;
        }

        /// <summary>
        /// [OOP Bridge] Подписывает классический C# метод на событие смерти этих сущностей.
        /// </summary>
        public static EntityBatch SubscribeOnDeath(this EntityBatch batch, Action<Entity> onDeathAction)
        {
            foreach (var entity in batch.Entities)
            {
                EntityEventRegistry.RegisterDestroy(entity, onDeathAction);
            }
            return batch;
        }

        // Поддержка цепочек DotsCommand
        public static DotsCommand Destroy(this DotsCommand cmd) => cmd.Do(b => b.Destroy());
        public static DotsCommand SetSpawnOnDeath(this DotsCommand cmd, Entity prefab) => cmd.Do(b => b.SetSpawnOnDeath(prefab));
        public static DotsCommand SubscribeOnDeath(this DotsCommand cmd, Action<Entity> action) => cmd.Do(b => b.SubscribeOnDeath(action));
    }
}