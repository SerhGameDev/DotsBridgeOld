﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;

namespace DotsBridge
{
    public static partial class Dots
    {
        #region Burst Jobs

        [BurstCompile]
        private struct SetDataImmediateJob<T> : IJob where T : unmanaged, IComponentData
        {
            [ReadOnly] public NativeArray<Entity> Entities;
            public ComponentLookup<T> Lookup;
            public T Data;

            public void Execute()
            {
                for (int i = 0; i < Entities.Length; i++)
                {
                    Entity entity = Entities[i];
                    if (Lookup.HasComponent(entity))
                    {
                        Lookup[entity] = Data;
                    }
                }
            }
        }

        [BurstCompile]
        private struct GetDataImmediateJob<T> : IJob where T : unmanaged, IComponentData
        {
            [ReadOnly] public NativeArray<Entity> Entities;
            [ReadOnly] public ComponentLookup<T> Lookup;
            [WriteOnly] public NativeArray<T> Results;

            public void Execute()
            {
                for (int i = 0; i < Entities.Length; i++)
                {
                    Entity entity = Entities[i];
                    if (Lookup.HasComponent(entity))
                    {
                        Results[i] = Lookup[entity];
                    }
                    else
                    {
                        Results[i] = default;
                    }
                }
            }
        }

        #endregion

        #region Data Reading (Immediate)

        /// <summary>
        /// Получает массив данных компонента для всех сущностей в батче.
        /// ВНИМАНИЕ: Обязательно вызовите Dispose() у результата для избежания утечек памяти!
        /// Скорость: Высокая (Burst), но вызывает Sync Point.
        /// Лимит: Легко обрабатывает 100 000+ объектов за раз. Не вызывать чаще 1-3 раз за кадр.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static NativeArray<T> GetData<T>(this EntityBatch batch, Allocator allocator = Allocator.Temp) where T : unmanaged, IComponentData
        {
            if (batch.Entities.IsEmpty) return new NativeArray<T>(0, allocator);

            var unmanagedWorld = batch.Manager.World.Unmanaged;
            SystemHandle bridgeSystem = unmanagedWorld.GetExistingUnmanagedSystem<DotsBridgeSystem>();

            if (bridgeSystem == SystemHandle.Null)
                bridgeSystem = batch.Manager.World.CreateSystem<DotsBridgeSystem>();

            ref SystemState state = ref unmanagedWorld.ResolveSystemStateRef(bridgeSystem);

            var query = batch.Manager.CreateEntityQuery(ComponentType.ReadOnly<T>());
            query.CompleteDependency();

            var lookup = state.GetComponentLookup<T>(true);
            lookup.Update(ref state);

            var results = new NativeArray<T>(batch.Entities.Length, allocator);

            new GetDataImmediateJob<T>
            {
                Entities = batch.Entities.AsArray(),
                Lookup = lookup,
                Results = results
            }.Run();

            return results;
        }

        /// <summary>
        /// Получает данные только первой сущности в батче (удобно для синглтонов).
        /// Скорость: Молниеносно (O(1)), но вызывает Sync Point.
        /// Лимит: Использовать для разовых проверок состояний.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T GetFirstData<T>(this EntityBatch batch) where T : unmanaged, IComponentData
        {
            if (batch.Entities.IsEmpty) return default;

            var query = batch.Manager.CreateEntityQuery(ComponentType.ReadOnly<T>());
            query.CompleteDependency();

            Entity firstEntity = batch.Entities[0];

            if (batch.Manager.HasComponent<T>(firstEntity))
            {
                return batch.Manager.GetComponentData<T>(firstEntity);
            }

            return default;
        }

        #endregion

        #region Data Writing (SetData)

        /// <summary>
        /// Устанавливает значения компонента для всех сущностей в батче.
        /// Скорость (Deferred): Сверхбыстро. Выдерживает 200 000+ объектов каждый кадр.
        /// Скорость (Immediate): Быстро (Burst), но вызывает Sync Point. Не более 2-5 вызовов за кадр.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch SetData<T>(this EntityBatch batch, T data, ApplyMode mode = ApplyMode.Deferred) where T : unmanaged, IComponentData
        {
            if (batch.Entities.IsEmpty) return batch;

            if (mode == ApplyMode.Immediate)
            {
                var unmanagedWorld = batch.Manager.World.Unmanaged;
                SystemHandle bridgeSystem = unmanagedWorld.GetExistingUnmanagedSystem<DotsBridgeSystem>();

                if (bridgeSystem == SystemHandle.Null)
                    bridgeSystem = batch.Manager.World.CreateSystem<DotsBridgeSystem>();

                ref SystemState state = ref unmanagedWorld.ResolveSystemStateRef(bridgeSystem);

                var query = batch.Manager.CreateEntityQuery(ComponentType.ReadWrite<T>());
                query.CompleteDependency();

                var lookup = state.GetComponentLookup<T>(false);
                lookup.Update(ref state);

                new SetDataImmediateJob<T>
                {
                    Entities = batch.Entities.AsArray(),
                    Lookup = lookup,
                    Data = data
                }.Run();
            }
            else
            {
                var ecbSystem = batch.Manager.World.GetExistingSystemManaged<EndSimulationEntityCommandBufferSystem>();
                var ecb = ecbSystem.CreateCommandBuffer();
                var entities = batch.Entities.AsArray();

                for (int i = 0; i < entities.Length; i++)
                {
                    if (batch.Manager.HasComponent<T>(entities[i]))
                        ecb.SetComponent(entities[i], data);
                }
            }

            return batch;
        }

        #endregion

        #region Structural Changes (Add / Remove)

        /// <summary>
        /// Добавляет компонент всем сущностям в батче (Structural Change).
        /// Скорость (Deferred): Быстро. Около 10 000 - 50 000 объектов без просадки FPS.
        /// Скорость (Immediate): Очень медленно (остановка потоков и перестроение памяти). Не использовать в Update!
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch AddComponent<T>(this EntityBatch batch, ApplyMode mode = ApplyMode.Deferred) where T : unmanaged, IComponentData
        {
            if (batch.Entities.IsEmpty) return batch;

            if (mode == ApplyMode.Immediate)
            {
                batch.Manager.AddComponent<T>(batch.Entities.AsArray());
            }
            else
            {
                var ecbSystem = batch.Manager.World.GetExistingSystemManaged<EndSimulationEntityCommandBufferSystem>();
                var ecb = ecbSystem.CreateCommandBuffer();
                var entities = batch.Entities.AsArray();

                for (int i = 0; i < entities.Length; i++)
                {
                    ecb.AddComponent<T>(entities[i]);
                }
            }

            return batch;
        }

        /// <summary>
        /// Удаляет компонент у всех сущностей в батче (Structural Change).
        /// Скорость (Deferred): Быстро. Около 10 000 - 50 000 объектов без просадки FPS.
        /// Скорость (Immediate): Очень медленно (остановка потоков и перестроение памяти). Не использовать в Update!
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch RemoveComponent<T>(this EntityBatch batch, ApplyMode mode = ApplyMode.Deferred) where T : unmanaged, IComponentData
        {
            if (batch.Entities.IsEmpty) return batch;

            if (mode == ApplyMode.Immediate)
            {
                batch.Manager.RemoveComponent<T>(batch.Entities.AsArray());
            }
            else
            {
                var ecbSystem = batch.Manager.World.GetExistingSystemManaged<EndSimulationEntityCommandBufferSystem>();
                var ecb = ecbSystem.CreateCommandBuffer();
                var entities = batch.Entities.AsArray();

                for (int i = 0; i < entities.Length; i++)
                {
                    ecb.RemoveComponent<T>(entities[i]);
                }
            }

            return batch;
        }

        #endregion

        #region Enableable Components (Enable / Disable)

        /// <summary>
        /// Переключает состояние IEnableableComponent. Не вызывает структурных изменений.
        /// Скорость (Deferred): Сверхбыстро (переключение битовой маски). 100 000+ объектов.
        /// Скорость (Immediate): Вызывает Sync Point. Рекомендуется только для событий.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch SetEnabled<T>(this EntityBatch batch, bool isEnabled, ApplyMode mode = ApplyMode.Deferred)
            where T : unmanaged, IComponentData, IEnableableComponent
        {
            if (batch.Entities.IsEmpty) return batch;

            var entities = batch.Entities.AsArray();

            if (mode == ApplyMode.Immediate)
            {
                var unmanagedWorld = batch.Manager.World.Unmanaged;
                SystemHandle bridgeSystem = unmanagedWorld.GetExistingUnmanagedSystem<DotsBridgeSystem>();

                if (bridgeSystem == SystemHandle.Null)
                    bridgeSystem = batch.Manager.World.CreateSystem<DotsBridgeSystem>();

                ref SystemState state = ref unmanagedWorld.ResolveSystemStateRef(bridgeSystem);

                var query = batch.Manager.CreateEntityQuery(ComponentType.ReadWrite<T>());
                query.CompleteDependency();

                for (int i = 0; i < entities.Length; i++)
                {
                    batch.Manager.SetComponentEnabled<T>(entities[i], isEnabled);
                }
            }
            else
            {
                var ecbSystem = batch.Manager.World.GetExistingSystemManaged<EndSimulationEntityCommandBufferSystem>();
                var ecb = ecbSystem.CreateCommandBuffer();

                for (int i = 0; i < entities.Length; i++)
                {
                    ecb.SetComponentEnabled<T>(entities[i], isEnabled);
                }
            }

            return batch;
        }

        /// <summary>
        /// Включает компонент (IEnableableComponent).
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch EnableComponent<T>(this EntityBatch batch, ApplyMode mode = ApplyMode.Deferred)
            where T : unmanaged, IComponentData, IEnableableComponent
        {
            return batch.SetEnabled<T>(true, mode);
        }

        /// <summary>
        /// Выключает компонент (IEnableableComponent).
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch DisableComponent<T>(this EntityBatch batch, ApplyMode mode = ApplyMode.Deferred)
            where T : unmanaged, IComponentData, IEnableableComponent
        {
            return batch.SetEnabled<T>(false, mode);
        }

        #endregion

        #region Safe Iteration & Modification

        public delegate void RefAction<T>(Entity entity, ref T component);

        /// <summary>
        /// Безопасно перебирает сущности для чтения. Защищает от утечек памяти.
        /// Скорость: Быстро (C# цикл). Вызывает Sync Point.
        /// Лимит: Около 10 000 - 50 000 объектов. Идеально для событий и UI. Не использовать для тяжелой математики каждый кадр.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void ForEach<T>(this EntityBatch batch, Action<Entity, T> action) where T : unmanaged, IComponentData
        {
            if (batch.Entities.IsEmpty) return;

            var unmanagedWorld = batch.Manager.World.Unmanaged;
            SystemHandle bridgeSystem = unmanagedWorld.GetExistingUnmanagedSystem<DotsBridgeSystem>();

            if (bridgeSystem == SystemHandle.Null)
                bridgeSystem = batch.Manager.World.CreateSystem<DotsBridgeSystem>();

            ref SystemState state = ref unmanagedWorld.ResolveSystemStateRef(bridgeSystem);

            var query = batch.Manager.CreateEntityQuery(ComponentType.ReadOnly<T>());
            query.CompleteDependency();

            var lookup = state.GetComponentLookup<T>(true);
            lookup.Update(ref state);

            var entities = batch.Entities.AsArray();

            for (int i = 0; i < entities.Length; i++)
            {
                Entity entity = entities[i];
                if (lookup.HasComponent(entity))
                {
                    action(entity, lookup[entity]);
                }
            }
        }

        /// <summary>
        /// Позволяет прочитать и мгновенно (или отложенно) изменить компонент по ссылке.
        /// Скорость: Быстро (0 аллокаций памяти), но вызывает Sync Point.
        /// Лимит: ~10 000 объектов. Идеально для разового применения урона, баффов или лечения.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch Modify<T>(this EntityBatch batch, RefAction<T> action, ApplyMode mode = ApplyMode.Deferred)
            where T : unmanaged, IComponentData
        {
            if (batch.Entities.IsEmpty) return batch;

            var unmanagedWorld = batch.Manager.World.Unmanaged;
            SystemHandle bridgeSystem = unmanagedWorld.GetExistingUnmanagedSystem<DotsBridgeSystem>();

            if (bridgeSystem == SystemHandle.Null)
                bridgeSystem = batch.Manager.World.CreateSystem<DotsBridgeSystem>();

            ref SystemState state = ref unmanagedWorld.ResolveSystemStateRef(bridgeSystem);

            var query = batch.Manager.CreateEntityQuery(ComponentType.ReadWrite<T>());
            query.CompleteDependency();

            var lookup = state.GetComponentLookup<T>(false);
            lookup.Update(ref state);

            var entities = batch.Entities.AsArray();

            if (mode == ApplyMode.Immediate)
            {
                for (int i = 0; i < entities.Length; i++)
                {
                    Entity entity = entities[i];
                    if (lookup.HasComponent(entity))
                    {
                        T component = lookup[entity];
                        action(entity, ref component);
                        lookup[entity] = component;
                    }
                }
            }
            else
            {
                var ecbSystem = batch.Manager.World.GetExistingSystemManaged<EndSimulationEntityCommandBufferSystem>();
                var ecb = ecbSystem.CreateCommandBuffer();

                for (int i = 0; i < entities.Length; i++)
                {
                    Entity entity = entities[i];
                    if (lookup.HasComponent(entity))
                    {
                        T component = lookup[entity];
                        action(entity, ref component);
                        ecb.SetComponent(entity, component);
                    }
                }
            }

            return batch;
        }

        /// <summary>
        /// Экспортирует данные в стандартный C# List (например, для использования LINQ).
        /// ВНИМАНИЕ: Создает нагрузку на Garbage Collector!
        /// Лимит: Желательно не более 10 000 объектов во избежание фризов от сборщика мусора.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static List<T> CopyToManagedList<T>(this EntityBatch batch) where T : unmanaged, IComponentData
        {
            var list = new List<T>(batch.Entities.Length);

            batch.ForEach<T>((entity, component) =>
            {
                list.Add(component);
            });

            return list;
        }
        #endregion

        #region Conditions & Checks

        /// <summary>
        /// Проверяет, существует ли компонент у ПЕРВОЙ сущности в батче.
        /// Скорость: Мгновенно (O(1)). Не вызывает Sync Point, так как просто читает метаданные архетипа.
        /// Лимит: Отсутствует. Можно вызывать сколько угодно раз за кадр.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool HasComponent<T>(this EntityBatch batch) where T : unmanaged, IComponentData
        {
            if (batch.Entities.IsEmpty) return false;

            // Проверка наличия компонента не требует ожидания фоновых потоков,
            // так как структура архетипа меняется только на главном потоке.
            return batch.Manager.HasComponent<T>(batch.Entities[0]);
        }

        /// <summary>
        /// Проверяет, включен ли компонент (IEnableableComponent) у ПЕРВОЙ сущности в батче.
        /// Скорость: Молниеносно (O(1)), но вызывает Sync Point для безопасного чтения.
        /// Лимит: Использовать для проверок состояний (например, жив ли игрок, в стане ли он).
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsComponentEnabled<T>(this EntityBatch batch)
            where T : unmanaged, IComponentData, IEnableableComponent
        {
            if (batch.Entities.IsEmpty) return false;

            // Sync Point: ждем завершения фоновых задач, так как какая-то джоба 
            // могла прямо сейчас асинхронно переключать этот компонент.
            var query = batch.Manager.CreateEntityQuery(ComponentType.ReadOnly<T>());
            query.CompleteDependency();

            return batch.Manager.IsComponentEnabled<T>(batch.Entities[0]);
        }
        /// <summary>
        /// Возвращает количество сущностей в текущем батче.
        /// Скорость: Мгновенно (O(1)). Не вызывает Sync Point, так как просто читает длину закэшированного массива.
        /// Лимит: Отсутствует. Идеально подходит для проверок в Update.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int Count(this EntityBatch batch)
        {
            if (batch.Entities.IsEmpty) return 0;

            return batch.Entities.Length;
        }

        /// <summary>
        /// Проверяет, пустой ли батч (нет ни одной сущности).
        /// Скорость: Мгновенно (O(1)). Не вызывает Sync Point.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsEmpty(this EntityBatch batch)
        {
            return batch.Entities.IsEmpty || batch.Entities.Length == 0;
        }

        #endregion

        // ... твой предыдущий код ...

        #region Debug & Logging

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static void PrintLog(BridgeLogType logType, string message)
        {
            switch (logType)
            {
                case BridgeLogType.Normal: UnityEngine.Debug.Log(message); break;
                case BridgeLogType.Warning: UnityEngine.Debug.LogWarning(message); break;
                case BridgeLogType.Error: UnityEngine.Debug.LogError(message); break;
            }
        }
        /// <summary>
        /// Выводит в консоль сообщение, если количество сущностей в батче больше указанного порога.
        /// Скорость: Мгновенно (O(1)).
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch LogCount(this EntityBatch batch, BridgeLogType logType = BridgeLogType.Normal, string customMessage = "")
        {
            PrintLog(logType, "Количество сущностей: " + batch.Count() + ", "+ customMessage);
            return batch; // Возвращаем batch для поддержки цепочек вызовов (Fluent API)
        }

        /// <summary>
        /// Выводит в консоль сообщение, если количество сущностей в батче больше указанного порога.
        /// Скорость: Мгновенно (O(1)).
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch LogIfCountGreaterThan(this EntityBatch batch, int threshold, BridgeLogType logType = BridgeLogType.Normal, string customMessage = "")
        {
            int count = batch.Count();
            if (count > threshold)
            {
                string msg = string.IsNullOrEmpty(customMessage)
                    ? $"[DotsBridge] Количество сущностей ({count}) превышает порог ({threshold})."
                    : $"[DotsBridge] {customMessage} | Сущностей: {count} (Порог: {threshold})";

                PrintLog(logType, msg);
            }
            return batch; // Возвращаем batch для поддержки цепочек вызовов (Fluent API)
        }

        /// <summary>
        /// Выводит в консоль сообщение, если батч пуст или количество сущностей меньше либо равно нулю.
        /// Скорость: Мгновенно (O(1)).
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch LogIfCountLessOrEqualZero(this EntityBatch batch, BridgeLogType logType = BridgeLogType.Warning, string customMessage = "")
        {
            int count = batch.Count();
            if (count <= 0)
            {
                string msg = string.IsNullOrEmpty(customMessage)
                    ? $"[DotsBridge] Батч пуст (Количество сущностей: {count})."
                    : $"[DotsBridge] {customMessage} | Сущностей: {count}";

                PrintLog(logType, msg);
            }
            return batch;
        }

        /// <summary>
        /// Выводит в консоль сообщение, если количество сущностей с указанным компонентом больше порога.
        /// ВНИМАНИЕ: Вызывает Sync Point для безопасного чтения.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch LogIfComponentCountGreaterThan<T>(this EntityBatch batch, int threshold, BridgeLogType logType = BridgeLogType.Normal, string customMessage = "") where T : unmanaged, IComponentData
        {
            if (batch.Entities.IsEmpty) return batch;

            // Sync Point для безопасности
            var query = batch.Manager.CreateEntityQuery(ComponentType.ReadOnly<T>());
            query.CompleteDependency();

            int count = 0;
            var entities = batch.Entities.AsArray();
            for (int i = 0; i < entities.Length; i++)
            {
                if (batch.Manager.HasComponent<T>(entities[i])) count++;
            }

            if (count > threshold)
            {
                string msg = string.IsNullOrEmpty(customMessage)
                    ? $"[DotsBridge] Количество компонентов {typeof(T).Name} ({count}) превышает порог ({threshold})."
                    : $"[DotsBridge] {customMessage} | Компонентов {typeof(T).Name}: {count} (Порог: {threshold})";

                PrintLog(logType, msg);
            }
            return batch;
        }

        /// <summary>
        /// Выводит в консоль сообщение, если количество сущностей с указанным компонентом меньше либо равно нулю.
        /// ВНИМАНИЕ: Вызывает Sync Point для безопасного чтения.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EntityBatch LogIfComponentCountLessOrEqualZero<T>(this EntityBatch batch, BridgeLogType logType = BridgeLogType.Warning, string customMessage = "") where T : unmanaged, IComponentData
        {
            if (batch.Entities.IsEmpty)
            {
                PrintLog(logType, string.IsNullOrEmpty(customMessage) ? $"[DotsBridge] Батч пуст, компонентов {typeof(T).Name}: 0." : $"[DotsBridge] {customMessage} | Компонентов {typeof(T).Name}: 0");
                return batch;
            }

            // Sync Point для безопасности
            var query = batch.Manager.CreateEntityQuery(ComponentType.ReadOnly<T>());
            query.CompleteDependency();

            int count = 0;
            var entities = batch.Entities.AsArray();
            for (int i = 0; i < entities.Length; i++)
            {
                if (batch.Manager.HasComponent<T>(entities[i])) count++;
            }

            if (count <= 0)
            {
                string msg = string.IsNullOrEmpty(customMessage)
                    ? $"[DotsBridge] Компоненты {typeof(T).Name} отсутствуют в батче (Количество: {count})."
                    : $"[DotsBridge] {customMessage} | Компонентов {typeof(T).Name}: {count}";

                PrintLog(logType, msg);
            }
            return batch;
        }

        #endregion
    }
}