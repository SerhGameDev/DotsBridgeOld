﻿namespace DotsBridge
{
    public static partial class Dots
    {
        /// <summary>
        /// Тип вывода логов для дебага моста DOTS.
        /// </summary>
        public enum BridgeLogType
        {
            Normal,
            Warning,
            Error
        }

    }
}